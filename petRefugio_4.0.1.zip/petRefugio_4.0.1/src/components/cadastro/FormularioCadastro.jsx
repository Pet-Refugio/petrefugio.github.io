import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../../styles/cadastro/formulario.css';

const FormularioCadastro = () => {
  const [dados, setDados] = useState({
    nome: '',
    nascimento: '',
    email: '',
    senha: '',
    confirmarSenha: ''
  });
  const [erro, setErro] = useState('');
  const navigate = useNavigate();

  const mudarDado = (e) => {
    const { name, value } = e.target;
    setDados(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const enviarForm = (e) => {
    e.preventDefault();
    
    if (dados.senha !== dados.confirmarSenha) {
      setErro('As senhas não coincidem');
      return;
    }
    
    if (dados.senha.length < 6) {
      setErro('Senha precisa ter 6+ caracteres');
      return;
    }
    
    console.log('Dados enviados:', dados);
    alert('Cadastro feito!');
    navigate('/login');
  };

  return (
    <div className="card-cadastro">
      <h2>Criar Conta</h2>
      
      {erro && <div className="erro">{erro}</div>}
      
      <form onSubmit={enviarForm}>
        <div className="grupo-form">
          <label htmlFor="nome">Nome de Usuário</label>
          <input 
            type="text" 
            id="nome" 
            name="nome" 
            value={dados.nome}
            onChange={mudarDado}
            required 
          />
        </div>
        
        <div className="grupo-form">
          <label htmlFor="nascimento">Data de Nascimento</label>
          <input 
            type="date" 
            id="nascimento" 
            name="nascimento" 
            value={dados.nascimento}
            onChange={mudarDado}
            required 
          />
        </div>
        
        <div className="grupo-form">
          <label htmlFor="email">Email</label>
          <input 
            type="email" 
            id="email" 
            name="email" 
            value={dados.email}
            onChange={mudarDado}
            required 
          />
        </div>
        
        <div className="grupo-form">
          <label htmlFor="senha">Senha</label>
          <input 
            type="password" 
            id="senha" 
            name="senha" 
            value={dados.senha}
            onChange={mudarDado}
            required 
          />
        </div>
        
        <div className="grupo-form">
          <label htmlFor="confirmarSenha">Confirmar Senha</label>
          <input 
            type="password" 
            id="confirmarSenha" 
            name="confirmarSenha" 
            value={dados.confirmarSenha}
            onChange={mudarDado}
            required 
          />
        </div>
        
        <div className="acoes">
          <button type="submit" className="botao">Cadastrar</button>
          <Link to="/" className="botao secundario">Voltar</Link>
        </div>
      </form>
      
      <div className="links">
        Já tem conta? <Link to="/login">Entrar</Link>
      </div>
    </div>
  );
};

export default FormularioCadastro;