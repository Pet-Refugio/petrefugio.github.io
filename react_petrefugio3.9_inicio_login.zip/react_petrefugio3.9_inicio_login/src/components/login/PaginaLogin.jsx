import HeaderCadastro from '../home/Footer';
import Footer from '../cadastro/HeaderCadastro';
import formularioLogin from '../login/FormularioLogin';

function PaginaLogin() {
    return(
        <div className="pagina-cadastro">
      <HeaderCadastro />
      <FormularioLogin/>
      <Footer />
      </div>
    )
}
export default PaginaLogin;