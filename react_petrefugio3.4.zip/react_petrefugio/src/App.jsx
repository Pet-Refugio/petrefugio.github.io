import './styles/style.css';
import Header from './components/Header';
import Hero from './components/Hero';
import Sobre from './components/Sobre';
import Recursos from './components/Recursos';
import TiposConta from './components/TiposConta';
import Chamada from './components/Chamada';
import Footer from './components/Footer';

function App() {
  return (
    <>
      <Header />
      <Hero />
      <Sobre />
      <Recursos />
      <TiposConta />
      <Chamada />
      <Footer />
    </>
  );
}

export default App;
