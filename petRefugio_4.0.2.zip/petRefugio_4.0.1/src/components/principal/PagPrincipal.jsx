import '../../styles/principal/PagPrincipal.css';
import headerPrincipal  from './header.jsx';
export default function PagPrincipal (){
    return(
        <div className="conteinerPP">
        <headerPrincipal/>
        </div>
    )
}