
import '../../styles/principal/header.css'
export default function headerPrincipal(){
    return(
        <div className="headerPP">
            <ul>
                <li>oi</li>
                <li>oi</li>
                <li>oi</li>
                <li>oi</li>
            </ul>
        </div>
    )
}